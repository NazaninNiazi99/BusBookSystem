package backend;

public class CompanySelectionBackend {
    public void manageCompanySelection() {
        System.out.println("Managing bus company selection...");
    }
}
