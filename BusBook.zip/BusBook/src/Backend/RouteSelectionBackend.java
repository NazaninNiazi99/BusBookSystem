package backend;

import java.util.UUID;
import java.util.HashSet;

public class RouteSelectionBackend {
    private HashSet<String> selectedRoutes;

    public RouteSelectionBackend() {
        selectedRoutes = new HashSet<>();
    }

    public String selectRoute(String route) {
        if (selectedRoutes.add(route)) {
            return "Route selected: " + route;
        }
        return "Route already selected.";
    }

    public String listRoutes() {
        return "Available Routes: " + selectedRoutes.toString();
    }
}
