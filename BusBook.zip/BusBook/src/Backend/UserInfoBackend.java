package backend;

import java.util.UUID;

public class UserInfoBackend {
    private String userId;

    public UserInfoBackend() {
        userId = UUID.randomUUID().toString();
    }

    public String getUserId() {
        return "User session ID: " + userId;
    }
}
