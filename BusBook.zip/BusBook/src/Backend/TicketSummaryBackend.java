package backend;

public class TicketSummaryBackend {
    public String generateTicketSummary(String route, String company, int seat) {
        return "Ticket Summary:\nRoute: " + route +
               "\nBus Company: " + company +
               "\nSeat: " + seat;
    }
}
