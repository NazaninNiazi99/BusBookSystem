package backend;

import java.util.HashSet;

public class SeatSelectionBackend {
    private HashSet<Integer> availableSeats;

    public SeatSelectionBackend() {
        availableSeats = new HashSet<>();
        // Preload seats 1 to 50 as available
        for (int i = 1; i <= 50; i++) {
            availableSeats.add(i);
        }
    }

    public String selectSeat(int seatNumber) {
        if (availableSeats.remove(seatNumber)) {
            return "Seat number " + seatNumber + " successfully reserved.";
        }
        return "Seat already taken or invalid.";
    }

    public String listAvailableSeats() {
        return "Available seats: " + availableSeats.toString();
    }
}
